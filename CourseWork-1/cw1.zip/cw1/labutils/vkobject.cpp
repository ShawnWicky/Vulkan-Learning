#include "vkobject.hpp"

// Just includes vkobject.hpp -- this serves as a test that the header compiles
// by itself.
