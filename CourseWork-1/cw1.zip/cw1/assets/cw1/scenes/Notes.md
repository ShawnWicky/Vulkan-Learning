Assets / Model Data
===================

Models sourced from 

"TDA 362/DIT223 Tutorials"
http://www.cse.chalmers.se/edu/course/TDA362/tutorials/index.html

with permission from the tutorial's authors.

Some of the models have been imported into Blender and re-exported. This
process causes object's meshes with identical materials to be merged.
