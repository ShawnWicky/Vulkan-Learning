The Release Notes and getting started guide for this SDK is located online at: https://vulkan.lunarg.com/doc/sdk

Most recent version of Release Notes: https://vulkan.lunarg.com/doc/sdk/latest/linux/release_notes.html

Most recent version of Getting Started Guide: https://vulkan.lunarg.com/doc/sdk/latest/linux/getting_started.html
