#define TINYOBJLOADER_IMPLEMENTATION 1
#include <tiny_obj_loader.h>
